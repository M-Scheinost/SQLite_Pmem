Directory lib_x64
2011-02-23

The directory is used in 64b Windows builds with Visual Studio 2008 and later.

Deploy the relevant 64b solidDB import libraries (ODBC driver, SMA driver, etc.)

Examples:
solidimpodbca.lib
solidimpsma.lib