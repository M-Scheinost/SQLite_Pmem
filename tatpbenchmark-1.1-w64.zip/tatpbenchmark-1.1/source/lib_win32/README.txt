Directory lib_win32
2011-03-02

The directory is used in 32b Windows builds when TATP is linked directly
and dynamically with the solidDB ANSI ODBC driver (sacw3265.dll) 
or with the Solid LLA (Acclerator) driver (ssolidac65.dll)

Deploy solidDB import libraries here:

solidimpac.lib
solidimpodbca.lib